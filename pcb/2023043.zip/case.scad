$fn=100;
dia = 2.2;

module hole(x, y, diameter) {
	translate([x, y, 0]) {
		cylinder(h=3, r=diameter / 2, center=true);
	}
}

module screws() {
	translate([-90.37,150.37,0]){
		hole(117.072, -83.686, dia);
		hole(136.172, -59.886, dia);
		hole(154.172, -78.986, dia);
		hole(173.172, -102.686, dia);
		hole(194.072, -52.686, dia);
		hole(207.373, -107.086, dia);
	}
}

difference(){
	linear_extrude(1.6+3.5)
	offset(2)
		import("/home/adi/repo/split_keyboard/electroholics/split/split-Edge_Cuts.svg");
	translate([0,0,3.5])
	linear_extrude(3.5)
	import("/home/adi/repo/split_keyboard/electroholics/split/split-Edge_Cuts.svg");
	screws();
};
